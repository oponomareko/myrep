#!/bin/bash

echo "Starting nginx"
nginx -g 'daemon off;'
