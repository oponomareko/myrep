#!/bin/bash

yum update
yum install -y ${package_to_install}
